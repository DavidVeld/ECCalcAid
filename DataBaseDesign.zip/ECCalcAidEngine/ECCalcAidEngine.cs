﻿using ECCalcAidData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECCalcAidEngine
{
    public class ECCAEngine
    {
        public ECCAEngine(ECCAProject ECCAProjectClass)
        {

        }
    }
}
