﻿namespace ECCalcAidData.Elements
{
    enum MaterialType
    {
        General,
        Steel,
        Concrete,
        imber
    }
}