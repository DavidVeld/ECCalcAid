﻿using System;

namespace ECCalcAidData.Elements
{
    [Serializable]
    public class ECCAElement
    {
    }
}